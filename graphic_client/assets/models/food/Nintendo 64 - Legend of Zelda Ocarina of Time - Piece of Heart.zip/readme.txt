please give credit to alec pike when used
